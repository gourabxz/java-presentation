$(document).ready(function () {
    
    var count = 0;
    check();
    $("body").keyup(function (e) {
        switch (e.which) {
            case 37: // left
                count--;
                $(".count").val(count);
                break;

            case 38: // up
                slideUp();
                break;

            case 39: // right
                count++;
                $(".count").val(count);
                check();
                break;

            case 40: // down
                break;

            default:
                return; // exit this handler for other keys
        }
        e.preventDefault(); // prevent the default action (scroll / move caret)
    });

    function check() {
        if (count == 0) {
            slide0();
        } else if (count == 1) {
            slideOne();
        } else if (count == 2) {
            slide2();
        } else if (count == 3) {
            slide3();
        } else if (count == 4) {
            slide4();
        }
        else if (count == 5) {
            window.location.href = "./page2.html";

        }
    }

    function slide0() {
        anime({
            targets: '.rootSlide1',
            opacity: 1
        })
    }

    function slideOne() {
        anime({
            targets: '.main-title',
            top: 50,
            easing: 'easeInOutQuad'
        });
        anime({
            targets: '.introBox',
            bottom: 70,
            easing: 'easeInOutQuad',
            delay: 500
        });
    }

    function slide2() {
        anime({
            targets: '.step1, .topicBoxHead',
            opacity: 1
        });
    }

    function slide3() {
        anime({
            targets: '.step2',
            opacity: 1
        });
    }

    function slide4() {
        anime({
            targets: '.step3',
            opacity: 1
        });
    }

    function slide5() {
       
    }
});
